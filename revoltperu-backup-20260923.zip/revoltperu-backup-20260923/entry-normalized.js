import app from "./index.js";

export default {
  async fetch(request, env, ctx) {
    const response = await app.fetch(request, env, ctx);
    if (response.headers.get("content-type")) return response;
    const headers = new Headers(response.headers);
    const path = new URL(request.url).pathname;
    if (path === "/admin" || path === "/" || path.endsWith(".html")) {
      headers.set("content-type", "text/html; charset=UTF-8");
    }
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  },
};
