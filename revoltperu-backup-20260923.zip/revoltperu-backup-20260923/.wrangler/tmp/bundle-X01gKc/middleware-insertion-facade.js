				import worker, * as OTHER_EXPORTS from "C:\\Users\\WINDOWS\\Documents\\Codex\\2026-08-31\\github-plugin-github-openai-curated-remote-4\\work\\catalogo-delete\\revolt-peru-catalogo\\entry-normalized.js";
				import * as __MIDDLEWARE_0__ from "C:\\Users\\WINDOWS\\Documents\\Codex\\2026-08-31\\github-plugin-github-openai-curated-remote-4\\work\\catalogo-delete\\node_modules\\.pnpm\\wrangler@4.92.0_@cloudflare+workers-types@4.20260515.1\\node_modules\\wrangler\\templates\\middleware\\middleware-ensure-req-body-drained.ts";

				export * from "C:\\Users\\WINDOWS\\Documents\\Codex\\2026-08-31\\github-plugin-github-openai-curated-remote-4\\work\\catalogo-delete\\revolt-peru-catalogo\\entry-normalized.js";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default
				]
				export default worker;